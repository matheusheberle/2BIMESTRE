let valor_gasolina = document.querySelector("#valor_gasolina");
let valor_litro = document.querySelector("#valor_litro");
let btn_gasolina = document.querySelector("#btn_gasolina");
let litros = document.querySelector("#litros");

function abastecimento(){
    let valor1 = Number(valor_gasolina.value);
    let valor2 = Number(valor_litro.value);
    let calculos;
        if (valor2 <= 0){
            calculos = 0;
        } else {
            calculos = valor1 / valor2;
        }
    litros.innerHTML = 'Com R$ ' + valor1.toFixed(2) + ', você abastece ' + calculos.toFixed(2) + ' litros';

}
btn_gasolina.onclick = function(){
    abastecimento();
}