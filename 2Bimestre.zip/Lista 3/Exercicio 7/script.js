let dia_inicial = document.querySelector("#dia_inicial");
let mes_inicial = document.querySelector("#mes_inicial");
let dias_que_passam = document.querySelector("#dias_que_passam");
let btn_dias_que_passam = document.querySelector("#btn_dias_que_passam");

function dias_passados(){
    let dia = Number(dia_inicial.value);
    let mes = Number(mes_inicial.value);

    if (mes <= 0) {
    mes = 1;
    }
       
    
    let calc_dias_mes = (mes - 1) * 30 + dia;   
    
    dias_que_passam.innerHTML = 'Se passaram ' + calc_dias_mes + 
    ' dias desde o começo do Ano!'

}

btn_dias_que_passam.onclick = function(){
    dias_passados();
}