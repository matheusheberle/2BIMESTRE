let btn_mais_p = document.querySelector("#camisa-p-mais");
let btn_menos_p = document.querySelector("#camisa-p-menos");

let btn_mais_m = document.querySelector("#camisa-m-mais");
let btn_menos_m = document.querySelector("#camisa-m-menos");

let btn_mais_g = document.querySelector("#camisa-g-mais");
let btn_menos_g = document.querySelector("#camisa-g-menos");

let btn_calc_camisas = document.querySelector("#calcular-pedido");

let camisa_p = document.querySelector("#camisa-p-quantidade");
let camisa_m = document.querySelector("#camisa-m-quantidade");
let camisa_g = document.querySelector("#camisa-g-quantidade");

let resultado_vendas_camisas = document.querySelector("#resultado-pedido-camisas");

btn_mais_p.onclick = function() {
    camisa_p.value = Number(camisa_p.value) + 1;
}
btn_menos_p.onclick = function() {
    camisa_p.value = Number(camisa_p.value) - 1;
    if (camisa_p.value <= 0) {
        camisa_p.value = 0;
    }
}
btn_mais_m.onclick = function() {
    camisa_m.value = Number(camisa_m.value) + 1;
}
btn_menos_m.onclick = function() {
    camisa_m.value = Number(camisa_m.value) - 1;
    if (camisa_m.value <= 0) {
        camisa_m.value = 0;
    }
}
btn_mais_g.onclick = function() {
    camisa_g.value = Number(camisa_g.value) + 1;
}
btn_menos_g.onclick = function() {
    camisa_g.value = Number(camisa_g.value) - 1;
    if (camisa_g.value <= 0) {
        camisa_g.value = 0;
    }
}

function vender_camisas() {
    resultado_vendas_camisas.innerHTML = '';

    let qtd_p = Number(camisa_p.value);
    let qtd_m = Number(camisa_m.value);
    let qtd_g = Number(camisa_g.value);

    if (qtd_p < 2) {
        resultado_vendas_camisas.innerHTML = qtd_p + ' Camisa Pequena<br>' +
            'Total de R$ ' + (qtd_p * 10).toFixed(2) + '<br>';
    } else {
        resultado_vendas_camisas.innerHTML = qtd_p + ' Camisas Pequenas<br>' +
            'Total de R$ ' + (qtd_p * 10).toFixed(2) + '<br>';
    }

    if (qtd_m < 2) {
        resultado_vendas_camisas.innerHTML += '<br>' + qtd_m + ' Camisa Média<br>' +
            'Total de R$ ' + (qtd_m * 12).toFixed(2) + '<br>';
    } else {
        resultado_vendas_camisas.innerHTML += '<br>' + qtd_m + ' Camisas Médias<br>' +
            'Total de R$ ' + (qtd_m * 12).toFixed(2) + '<br>';
    }

    if (qtd_g < 2) {
        resultado_vendas_camisas.innerHTML += '<br>' + qtd_g + ' Camisa Grande<br>' +
            'Total de R$ ' + (qtd_g * 15).toFixed(2) + '<br>';
    } else {
        resultado_vendas_camisas.innerHTML += '<br>' + qtd_g + ' Camisas Grandes<br>' +
            'Total de R$ ' + (qtd_g * 15).toFixed(2) + '<br>';
    }

    let total_compar = (qtd_p * 10) + (qtd_m * 12) + (qtd_g * 15);

    if (total_compar == 0) {
        resultado_vendas_camisas.innerHTML += '<br>Pedido Vazio';
    } else {
        resultado_vendas_camisas.innerHTML += '<br><strong>TOTAL(R$): ' + total_compar.toFixed(2) + '</strong>';
    }
}

btn_calc_camisas.onclick = function() {
    vender_camisas();
}
