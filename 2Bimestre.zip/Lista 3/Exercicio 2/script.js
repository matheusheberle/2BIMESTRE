let cavalos_comprados = document.querySelector("#cavalos_comprados");
let btn_calculo_haras = document.querySelector("#btn_calculo_haras");
let ferraduras_a_comprar = document.querySelector("#ferraduras_a_comprar");

function calcular_ferraduras(){
    let ferradura = 4
    let cavalos = Number(cavalos_comprados.value);
    let ferraduras_totais = ferradura * cavalos;

    ferraduras_a_comprar.innerHTML = 'Você precisa de: ' + ferraduras_totais + ' Ferraduras para equipar ' + cavalos + ' Cavalos.';
}

btn_calculo_haras.onclick = function(){
    calcular_ferraduras();
}