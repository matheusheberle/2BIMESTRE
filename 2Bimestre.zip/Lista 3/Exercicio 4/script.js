let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btn_calculo_dias = document.querySelector("#btn_calculo_dias");
let resposta = document.querySelector("#resposta");

function calular_anos(){
    let nome_input = nome.value;
    let idade_input = Number(idade.value);
    let anos = 365;

    let dias_de_vida = idade_input * anos;

    resposta.innerHTML = nome_input + ', Você tem ' + Number(dias_de_vida) + ' Dias de Vida!!!'
}

btn_calculo_dias.onclick = function(){
    calular_anos();
}