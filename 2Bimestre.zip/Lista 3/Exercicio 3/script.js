let pao = document.querySelector("#pao");
let broa = document.querySelector("#broa");
let btn_calculo_vendas = document.querySelector("#btn_calculo_vendas");
let lucros = document.querySelector("#lucros");

function calcular_paes(){
    let valor_pao = 0.12;
    let valor_broa = 1.50;
    let poupanca = 0.10;

    let quantidade_pao_vendidos = Number(pao.value);
    let quantidade_broa_vendidos = Number(broa.value);

    let vendas_dia_pao = valor_pao * quantidade_pao_vendidos;
    let vendas_dia_broa = valor_broa * quantidade_broa_vendidos;
    let vendas_totais_dia = vendas_dia_broa + vendas_dia_pao;

    let calculo_poupanca = vendas_totais_dia * poupanca;
    
    
    lucros.innerHTML = 'Vendas Totais do Dia: R$ ' + vendas_totais_dia.toFixed(2) + '<br>' + 
    'Saldo para Aplicação: R$ ' + calculo_poupanca.toFixed(2) + '<br>' +
    'Vendeu: ' + quantidade_pao_vendidos + ' Pães e ' + quantidade_broa_vendidos + ' Broas';
}

btn_calculo_vendas.onclick = function(){
    calcular_paes();
}