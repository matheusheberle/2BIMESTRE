let dias = document.querySelector("#dias");
let bt = document.querySelector("#bt");
let resultado = document.querySelector("#resultado");

function calculo(){
    
}

bt = function(){
    calculo();
}