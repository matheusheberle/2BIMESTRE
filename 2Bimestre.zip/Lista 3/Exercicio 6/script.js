let prato_kg = document.querySelector("#prato_kg");
let btn_kg = document.querySelector("#btn_kg");
let valor_a_pagar_kg = document.querySelector("#valor_a_pagar_kg");

function peso_kg(){
    let tara_prato = 0.800;
    let valor_kg = 12;
    let peso_prato = Number(prato_kg.value) - tara_prato;

    let valor_peso = peso_prato * valor_kg;
    if (peso_prato < 0){
        valor_peso = 0;
    }
    valor_a_pagar_kg.innerHTML = 'TARA: ' + tara_prato.toFixed(3) + '<br>' +
                                'PESO: ' + peso_prato.toFixed(3) + '(T)<br>' +
                                'R$/kg: ' + valor_kg.toFixed(2) + '(L)<br><br>' +
                                'TOTAL R$ ' + valor_peso.toFixed(2)
}

btn_kg.onclick = function(){
    peso_kg();
}