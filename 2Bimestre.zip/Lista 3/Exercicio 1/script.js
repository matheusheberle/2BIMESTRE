let altura = document.querySelector("#altura");
let base = document.querySelector("#base");
let btn_calculo_terreno = document.querySelector("#btn_calculo_terreno");
let area_total = document.querySelector("#area_total");

function calcular_area_terreno(){
    let altura1 = Number(altura.value);
    let base1 = Number(base.value);
    let area_calculo = altura1 * base1;

    area_total.innerHTML = area_calculo + ' m² ';
}

btn_calculo_terreno.onclick = function(){
    calcular_area_terreno();
}