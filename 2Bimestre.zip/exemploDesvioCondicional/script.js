let nota1Bim = document.querySelector("#nota1Bim");
let nota2Bim = document.querySelector("#nota2Bim");
let btAprovacao = document.querySelector("#btAprovacao");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularMediaAluno(){

    //retornando valores dos inpus e convertendo em numeros
    let nota1 = Number(nota1Bim.value);
    let nota2 = Number(nota2Bim.value);
    
    //calcular a media
    let media = (nota1 + nota2) / 2;

    //verifica se o aluno esta aprovado ou nao
    if(media >= 60){
        h3Resultado.textContent = "O aluno esta aprovado!";
    }else{
        h3Resultado.textContent = "O aluno esta reprovado!";
    }
}

btAprovacao.onclick = function(){
    calcularMediaAluno();
}
