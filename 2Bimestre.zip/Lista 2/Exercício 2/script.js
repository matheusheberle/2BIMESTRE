let inputPessoas = document.querySelector('#inputPessoas');
let btResultado = document.querySelector('#btResultado');
let h1Resultado = document.querySelector('#h1Resultado');

function Calculo(){
    let pessoas = Number(inputPessoas.value);

    let ovos = 2 * pessoas;

    let queijo = 50 * pessoas;

    h1Resultado.innerHTML = "Quantidade de ovo: "+ovos+"<br>"+
                            "Quantidade de queijo (em gramas): "+queijo;
}

btResultado.onclick = function(){
    Calculo();
}