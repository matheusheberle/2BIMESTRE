
let n1 = document.querySelector("#n1");
let n2 = document.querySelector("#n2");

let calc_n = document.querySelector("#calc_n");

let soma = document.querySelector("#soma");
let subtracao = document.querySelector("#subtracao");
let multiplicacao = document.querySelector("#multiplicacao");
let divisao = document.querySelector("#divisao");

function calculos_matematicos_basicos(){
    let input1 = Number(n1.value);
    let input2 = Number(n2.value);

    let somar = 'A soma é: ' + (input1 + input2);
    let subtrair = 'A subtração é: ' + (input1 - input2);
    let multiplicar = 'A multiplicação é: ' + input1 * input2;
    let dividir;
    if (input2 == 0) {
        dividir = 'A divisão é: 0 ';
    }else {
        dividir = 'A divisão é: ' + (input1 / input2).toFixed(2);
    }

    soma.textContent = somar
    subtracao.textContent = subtrair
    multiplicacao.textContent = multiplicar
    divisao.textContent = dividir

}

calc_n.onclick = function(){
    calculos_matematicos_basicos();
}