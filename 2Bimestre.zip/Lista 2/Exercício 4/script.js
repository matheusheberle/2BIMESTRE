let inputSabor1 = document.querySelector('#inputSabor1');
let inputSabor2 = document.querySelector('#inputSabor2');
let inputSabor3 = document.querySelector('#inputSabor3');
let inputSabor4 = document.querySelector('#inputSabor4');
let btPedido = document.querySelector('#btPedido');
let h2Total = document.querySelector('#h2Total')

function Calculo() {
    // Pega os valores dos sabores
    let sabor1 = inputSabor1.value.trim();
    let sabor2 = inputSabor2.value.trim();
    let sabor3 = inputSabor3.value.trim();
    let sabor4 = inputSabor4.value.trim();

    // Pega quantidade de refrigerante
    let qtdRefri = parseInt(inputRefri.value) || 0;

    // Verifica se todos os sabores estão preenchidos
    if (!sabor1 || !sabor2 || !sabor3 || !sabor4) {
        h2Total.innerHTML = "Por favor, preencha todos os 4 sabores.";
        return;
    }

    let sabores = [sabor1, sabor2, sabor3, sabor4];

    let precoPizza = 12;
    let precoRefri = 7;
    let total = (4 * precoPizza) + (qtdRefri * precoRefri);

    h2Total.innerHTML = 
        "Sabores: " + sabores.join(", ") + 
        "<br>Refrigerantes: " + qtdRefri + 
        "<br>Total a pagar: R$ " + total.toFixed(2);
}

btPedido.onclick = function(){
    Calculo();
}