let inputDolar = document.querySelector('#inputDolar');
let buttonCalcular = document.querySelector('#buttonCalcular');
let h1Resultado = document.querySelector('#h1Resultado');

function Cotacao(){
    let valor = Number(inputDolar.value);

    let porcento1 = (valor * 1.01).toFixed(2);

    let porcento2 = (valor * 1.02).toFixed(2);

    let porcento5 = (valor * 1.05).toFixed(2);

    let porcento10 = (valor * 1.10).toFixed(2);

    h1Resultado.innerHTML = "Aumento de 1%: "+porcento1+"<br>"+
                            "Aumento de 2%: "+porcento2+"<br>"+
                            "Aumento de 5%: "+porcento5+"<br>"+
                            "Aumento de 10%: "+porcento10
}

buttonCalcular.onclick = function(){
    Cotacao();
}