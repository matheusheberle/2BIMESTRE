    let Campo1 = document.querySelector("#Campo1");
    let Campo2 = document.querySelector("#Campo2");
    let BotaoSomar = document.querySelector("#BotaoSomar");
    let Resultado = document.querySelector("#Resultado");

    function SomarValores(){
        let ValorCampo1 = Number(Campo1.value);
        let ValorCampo2 = Number(Campo2.value);
        
        let Calculo = ValorCampo1 + ValorCampo2;

        Resultado.textContent = Calculo;
    }

    BotaoSomar.onclick = function(){
        SomarValores();
    }