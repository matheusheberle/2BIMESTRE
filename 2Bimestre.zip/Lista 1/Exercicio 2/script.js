    let InputQuiloProduto = document.querySelector('#InputQuiloProduto');
    let InputQuantidadeQuiloConsumido = document.querySelector('#InputQuantidadeQuiloConsumido');
    let ButtonEx2 = document.querySelector('#ButtonEx2');
    let ResultadoEx2 = document.querySelector('#ResultadoEx2');

    function Exercicio2(){
        let QuiloProduto = Number(InputQuiloProduto.value);
        let QuantidadeQuiloConsumido = Number(InputQuantidadeQuiloConsumido.value);
        let CalculoEx2 = QuiloProduto * QuantidadeQuiloConsumido;
        ResultadoEx2.textContent = CalculoEx2;
    }

    ButtonEx2.onclick = function(){
        Exercicio2();
    }