let valor = document.querySelector("#valor");
let botao = document.querySelector("#botao");
let resultado = document.querySelector("#resultado");

function mostrarImpar(){
    let valorimpar = Number(valor.value);

    if (valorimpar % 2 == 1){
        resultado.textContent = "Valor impar"
    }
    else {
        resultado.textContent = "Valor par"
    }
}

botao.onclick = function(){
    mostrarImpar();
}