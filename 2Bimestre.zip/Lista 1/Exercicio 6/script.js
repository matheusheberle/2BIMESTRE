let InputPrimeiroValor = document.querySelector("#InputPrimeiroValor");
let InputSegundoValor = document.querySelector("#InputSegundoValor");
let InputTerceiroValor = document.querySelector("#InputTerceiroValor");
let InputQuartoValor = document.querySelector("#InputQuartoValor");
let ButtonRetornarMenor = document.querySelector("#ButtonRetornarMenor");
let Resultado = document.querySelector("#Resultado");

function MostrarMenor(){
    let Valor1 = Number(InputPrimeiroValor.value);
    let Valor2 = Number(InputSegundoValor.value);
    let Valor3 = Number(InputTerceiroValor.value);
    let Valor4 = Number(InputQuartoValor.value);

    if(Valor1 > Valor2 > Valor3 > Valor4){
        Resultado.textContent = Valor1;
    } else if(Valor2 > Valor3 > Valor4 > Valor1){
        Resultado.textContent = Valor2;
    } else if(Valor3 > Valor4 > Valor2 > Valor1){
        Resultado.textContent = Valor3;
    } else if(Valor4 > Valor3 > Valor2 > Valor1){
        Resultado.textContent = Valor4;
    } else {
        Resultado.textContent = "Os valores são iguais"
    }
}

ButtonRetornarMenor.onclick = function(){
    MostrarMenor();
}