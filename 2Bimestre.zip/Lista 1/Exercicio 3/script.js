    let InputSaldo = document.querySelector('#InputSaldo');
    let ButtonReajuste = document.querySelector('#ButtonReajuste');
    let ResultadoEx3 = document.querySelector('#ResultadoEx3');

    function Exercicio3(){
        let Saldo = Number(InputSaldo.value);
        let CalculoEx3 = Saldo * 1.01;
        ResultadoEx3.textContent = CalculoEx3;
    }

    ButtonReajuste.onclick = function(){
        Exercicio3();
    }