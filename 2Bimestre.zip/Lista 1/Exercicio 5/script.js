let InputPrimeiroValor = document.querySelector("#InputPrimeiroValor");
let InputSegundoValor = document.querySelector("#InputSegundoValor");
let ButtonRetornarMaior = document.querySelector("#ButtonRetornarMaior");
let Resultado = document.querySelector("#Resultado");

function MostrarMaior(){
    let Valor1 = Number(InputPrimeiroValor.value);
    let Valor2 = Number(InputSegundoValor.value);

    if(Valor1 > Valor2){
        Resultado.textContent = Valor1;
    } else if(Valor2 > Valor1){
        Resultado.textContent = Valor2;
    } else {
        Resultado.textContent = "Os valores são iguais"
    }
}

ButtonRetornarMaior.onclick = function(){
    MostrarMaior();
}