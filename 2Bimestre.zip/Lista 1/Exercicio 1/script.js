let InputValorPago = document.querySelector("#InputValorPago");
    let InputValorProduto = document.querySelector("#InputValorProduto");
    let ButtonSomarTroco = document.querySelector("#ButtonSomarTroco");
    let ResultadoEx1 = document.querySelector("#ResultadoEx1");

    function Exercicio1(){
        let ValorPago = Number(InputValorPago.value);
        let ValorProduto = Number(InputValorProduto.value);
        let CalculoEx1 = ValorPago - ValorProduto;
        ResultadoEx1.textContent = CalculoEx1;
    }

    ButtonSomarTroco.onclick = function(){
        Exercicio1();
    }